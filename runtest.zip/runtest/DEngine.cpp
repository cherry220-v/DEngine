#include "DEngine.h"

#include <assets/AssetLoaderRegistration.hpp>
#include <assets/AssetRef.hpp>

#include <ecs/components/Transform.hpp>
#include <ecs/components/CameraComponent.hpp>
#include <ecs/components/PlayerComponent.hpp>
#include <ecs/components/LightComponent.hpp>
#include <ecs/components/ParticleEmitterComponent.hpp>
#include <ecs/components/SkeletonComponent.hpp>

#include <scene/Skybox.hpp>
#include <memory>
#include <vector>
#include <iostream>
#include <fstream>
#include <ecs/components/RigidBodyComponent.hpp>
#include <ecs/components/ColliderComponent.hpp>
#include <ecs/components/CharacterControllerComponent.hpp>
#include <ecs/components/MeshColliderComponent.hpp>

std::unique_ptr<Scene> loadScene(Application& app, IWindow* window)
{
    AssetManager& assetManager =
        AssetManager::get();
    auto scene =
        std::make_unique<Scene>();


    std::vector<std::string> faces =
    {
        "skybox/right.jpg",
        "skybox/left.jpg",
        "skybox/top.jpg",
        "skybox/bottom.jpg",
        "skybox/front.jpg",
        "skybox/back.jpg"
    };

    auto particleMat = assetManager.load<Material>("ecd38f9f-e145-46d4-a968-d255ec31b3f7");
    auto particleShader = particleMat->shader;

    auto skybox =
        std::make_shared<Skybox>(
            assetManager.load<Material>(
                "43eaf388-5ff9-4679-a919-195e71950728"
            ),
            faces
        );

    auto mat =
        assetManager.load<Material>(
            "71e469e7-932d-47f1-96e4-94b341ad77f9"
        );

    mat->color =
        glm::vec4(0.95f, 0.80f, 0.70f, 1.0f);

    auto lightEntity = scene->createEntity();
    auto& lightComponent = scene->addComponent<LightComponent>(lightEntity);
    lightComponent.type = LightCType::Point;
    lightComponent.intensity = 0.8f;
    auto& lightTransform = scene->addComponent<Transform>(lightEntity);
    lightTransform.position = { 0, 0, 0 };
    //lightComponent.direction = { -1.0f, -1.0f, -1.0f };

    auto particleEntity = scene->createEntity();
    auto& emitter = scene->addComponent<ParticleEmitterComponent>(particleEntity);
    auto& emitterTransform = scene->addComponent<Transform>(particleEntity);
    emitterTransform.position =
    {
        1.0f,
        -1.0f,
        0.0f
    };

    emitter.spawnRate = 5.0f;

    emitter.particleLifetime = 2.0f;

    emitter.spawnBoxMin =
    {
        -5.0f,
        0.0f,
        -5.0f
    };

    emitter.spawnBoxMax =
    {
         5.0f,
         2.0f,
         5.0f
    };

    emitter.startColor =
    {
        1.0f,
        1.0f,
        1.0f,
        1.0f
    };

    emitter.endColor =
    {
        1.0f,
        1.0f,
        1.0f,
        0.0f
    };

    emitter.useColorOverLifetime = true;
    emitter.spawnRadius = 2.0f;
    emitter.spawnHeight = 4.0f;
    emitter.spawnShape = ParticleSpawnShape::Box;
    emitter.direction = { 0, -1, 0 };
    emitter.sizeMin = 0.1f;
    emitter.sizeMax = 0.3f;

    particleMat->color = { 1.0f, 0.0f, 0.0f, 1.0f };

    emitter.material = AssetRef<Material>("ecd38f9f-e145-46d4-a968-d255ec31b3f7");

    Entity cube =
        scene->createEntity();

    auto& cubeTransform =
        scene->addComponent<Transform>(cube);

    cubeTransform.position =
    {
        0,
        0,
        -3
    };

    cubeTransform.scale = glm::vec3(4.0f);

    //auto& cubeRigidBody = scene->addComponent<RigidBodyComponent>(cube);
    //cubeRigidBody.mass = 2.0f;
    //auto& cubeCollider = scene->addComponent<ColliderComponent>(cube);
    //cubeCollider.size = glm::vec3(10.0f);
    //cubeCollider.type = ColliderComponent::Type::Box;

    auto& collider = scene->addComponent<MeshColliderComponent>(cube);
    collider.isConvex = true;

    auto& cubeMesh =
        scene->addComponent<ModelRendererComponent>(cube);

    cubeMesh.model = AssetRef<Model>("7fe983de-f5b4-447e-8226-042f4a6a704a");

    cubeMesh.material = AssetRef<Material>("71e469e7-932d-47f1-96e4-94b341ad77f9");

    Entity cube2 =
        scene->createEntity();

    scene->addComponent<Transform>(cube2);

    auto& cubeMesh2 =
        scene->addComponent<ModelRendererComponent>(cube2);

    auto& collider2 = scene->addComponent<MeshColliderComponent>(cube2);

    cubeMesh2.model = AssetRef<Model>("3996a039-1488-4465-a16d-d186407e3478");
    cubeMesh2.material = AssetRef<Material>{ "71e469e7-932d-47f1-96e4-94b341ad77f9" };

    Entity player =
        scene->createEntity();

    auto& playerTransform = scene->addComponent<Transform>(player);
    playerTransform.position = { 10, 10, 0 };

    scene->addComponent<PlayerComponent>(
        player
    );

    auto* playerComp =
        scene->getComponent<PlayerComponent>(
            player
        );

    auto& playerc = scene->addComponent<ColliderComponent>(player);
    playerc.type = ColliderComponent::Type::Capsule;
    playerc.size = { 0.8f, 1.8f, 0.8f };

    auto& chc = scene->addComponent<CharacterControllerComponent>(player);

    Entity camera =
        scene->createEntity(player);

    auto& camTransform =
        scene->addComponent<Transform>(camera);

    camTransform.position =
    {
        -15,
        0,
        -15
    };

    camTransform.setRotEuler(
        {
            0,
            0,
            0
        });

    auto& camComp = scene->addComponent<CameraComponent>(camera);

    camComp.fov = 60.0f;

    camComp.aspect = (float)window->getWidth() / (float)window->getHeight();

    playerComp->camera = camera;

    scene->setParent(camera, player);
    scene->setParent(lightEntity, player);

    app.engine()->setActiveCamera(
        camera
    );

    app.engine()->setPlayerEntity(
        player
    );

    return scene;
}

int main()
{
    Application app;

    WindowProps props;

    AssetManager& assetManager =
        AssetManager::get();

    assetManager.setAssetsPath(
        "C:/Users/Trash/DEngine/assets"
    );

    AssetLoaderRegistration::registerAll();

    assetManager.scanAssets();

    auto window =
        std::make_unique<GLFWWindow>(props);

    auto renderDevice =
        std::make_unique<OpenGLRenderDevice>();

    auto platform =
        std::make_unique<GLFWRenderPlatform>(
            window->gwindow()
        );

    auto renderer =
        std::make_unique<Renderer>();

    auto input =
        std::make_unique<GLFWInput>(
            window.get()
        );

    renderer->setDevice(
        std::move(renderDevice)
    );

    renderer->setPlatform(
        std::move(platform)
    );

    app.engine()->setRenderer(
        std::move(renderer)
    );

    app.engine()->setupRenderer();

    auto scene = loadScene(app, window.get());

    std::ifstream file("C:/Users/Trash/DEngine/assets/scenes/Main.scene");

    if (!file.is_open())
        std::cout << "FILE NOT OPEN\n";

    std::string text((std::istreambuf_iterator<char>(file)),
        std::istreambuf_iterator<char>());

    auto data = nlohmann::json::parse(text);


    auto sceneSerialized = Scene::deserialize(data);

    app.setWindow(
        std::move(window)
    );

    app.setInput(
        std::move(input)
    );

    app.engine()->setScene(
        std::move(scene)
    );

    //Entity camera = 4;
    //Entity player = 5;

    //app.engine()->setActiveCamera(
    //    &camera
    //);

    //app.engine()->setPlayerEntity(
    //    &player
    //);

    app.run();

    return 0;
}