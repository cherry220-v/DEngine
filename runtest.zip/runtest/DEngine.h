#pragma once

#include <core/Application.h>
#include <assets/AssetManager.hpp>

#include <ecs/entity/Entity.hpp>
#include <ecs/Scene.hpp>

#include <core/platform/window/glfw/GLFWWindow.hpp>
#include <core/platform/input/glfw/GLFWInput.hpp>
#include <core/platform/render/glfw/GLFWRenderPlatform.hpp>

#include <core/platform/window/win32/Win32Window.hpp>
#include <core/platform/input/win32/Win32Input.hpp>
#include <core/platform/render/win32/Win32RenderPlatform.hpp>

#include <render/renderer/Renderer.hpp>
#include <render/renderer/gl/OpenGLRenderDevice.hpp>

#include <render/mesh/Mesh.hpp>
#include <ecs/components/ModelRendererComponent.hpp>
#include <render/texture/Material.hpp>
#include <render/texture/Texture.hpp>
#include <render/shader/Shader.hpp>

#include <models/Model.hpp>

#include <geometry/Cube.hpp>

#include <editor/gizmos/TransformGizmo.hpp>
//#include <editor/gizmo/ImGuizmo.h>